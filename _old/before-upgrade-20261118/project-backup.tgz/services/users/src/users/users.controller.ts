import { Controller, Get, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { TokenType } from '../auth/token-type.decorator';
import { CurrentUser } from '../auth/current-user.decorator';
import { AuthUser } from '../auth/jwt';
import { UsersService } from './users.service';
import { UserDto } from './dto';

@Controller('users')
export class UsersController {
  constructor(private readonly usersService: UsersService) {}

  /**
   * 본인 정보 조회. 신원은 항상 검증된 access 토큰의 sub 에서만 꺼냅니다.
   * x-user-id 헤더가 토큰 sub 와 다르면 JwtAuthGuard 가 401 을 반환합니다.
   */
  @Get('me')
  @UseGuards(JwtAuthGuard)
  @TokenType('access')
  async me(@CurrentUser() user: AuthUser): Promise<UserDto> {
    return this.usersService.findMe(user.userId);
  }
}
