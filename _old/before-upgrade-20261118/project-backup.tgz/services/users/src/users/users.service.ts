import { randomBytes } from 'crypto';
import {
  ConflictException,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../prisma.service';
import { hashPassword, verifyPassword } from '../password';
import { signAccessToken } from '../auth/jwt';
import { intEnv, requireEnv } from '../config';
import { LoginDto, LoginResponse, SignupDto, UserDto } from './dto';

const INVALID_CREDENTIALS = 'Invalid email or password';

interface UserRow {
  id: string;
  email: string;
  passwordHash: string;
  role: string;
  createdAt: Date;
}

function normalizeEmail(email: string): string {
  return String(email ?? '').trim().toLowerCase();
}

function toUserDto(user: UserRow): UserDto {
  return {
    id: user.id,
    email: user.email,
    role: user.role as UserDto['role'],
    createdAt: user.createdAt.toISOString(),
  } as UserDto;
}

@Injectable()
export class UsersService {
  private dummyHashPromise: Promise<string> | null = null;

  constructor(private readonly prisma: PrismaService) {}

  /** 존재하지 않는 이메일에도 bcrypt 비교를 수행해 응답 시간 차이를 줄이기 위한 더미 해시 */
  private getDummyHash(): Promise<string> {
    if (!this.dummyHashPromise) {
      this.dummyHashPromise = hashPassword(randomBytes(24).toString('hex'));
    }
    return this.dummyHashPromise;
  }

  async signup(dto: SignupDto): Promise<UserDto> {
    const email = normalizeEmail(dto.email);
    const existing = await this.prisma.user.findUnique({ where: { email } });
    if (existing) {
      throw new ConflictException('Email already registered');
    }
    const passwordHash = await hashPassword(dto.password);
    try {
      const created = await this.prisma.user.create({
        data: { email, passwordHash, role: 'USER' },
      });
      return toUserDto(created as UserRow);
    } catch (err) {
      if (
        err instanceof Prisma.PrismaClientKnownRequestError &&
        err.code === 'P2002'
      ) {
        throw new ConflictException('Email already registered');
      }
      if (
        typeof err === 'object' &&
        err !== null &&
        (err as { code?: unknown }).code === 'P2002'
      ) {
        throw new ConflictException('Email already registered');
      }
      throw err;
    }
  }

  async login(dto: LoginDto): Promise<LoginResponse> {
    const email = normalizeEmail(dto.email);
    const password = String(dto.password ?? '');
    const user = (await this.prisma.user.findUnique({
      where: { email },
    })) as UserRow | null;

    if (!user) {
      // 타이밍 차이를 줄이기 위해 더미 해시와 비교 후 동일한 오류를 반환
      await verifyPassword(password, await this.getDummyHash());
      throw new UnauthorizedException(INVALID_CREDENTIALS);
    }

    const ok = await verifyPassword(password, user.passwordHash);
    if (!ok) {
      throw new UnauthorizedException(INVALID_CREDENTIALS);
    }

    const secret = requireEnv('JWT_SECRET');
    const expiresIn = intEnv('JWT_EXPIRES_IN_SECONDS', 3600);
    const role: 'USER' | 'ADMIN' = user.role === 'ADMIN' ? 'ADMIN' : 'USER';
    const accessToken = signAccessToken(
      { id: user.id, email: user.email, role },
      secret,
      expiresIn,
    );

    return {
      accessToken,
      tokenType: 'Bearer' as const,
      expiresIn,
      user: toUserDto(user),
    } as LoginResponse;
  }

  async findMe(userId: string): Promise<UserDto> {
    const uuidRe =
      /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
    if (!userId || !uuidRe.test(userId)) {
      throw new UnauthorizedException();
    }
    const user = (await this.prisma.user.findUnique({
      where: { id: userId },
    })) as UserRow | null;
    if (!user) {
      throw new UnauthorizedException();
    }
    return toUserDto(user);
  }
}
