import { Type } from 'class-transformer';
import {
  ArrayMaxSize,
  ArrayMinSize,
  IsArray,
  IsIn,
  IsInt,
  IsNotEmpty,
  IsOptional,
  IsString,
  Max,
  MaxLength,
  Min,
  ValidateNested,
} from 'class-validator';
import { ORDER_STATUSES, OrderStatus, toStatusLabel } from './order-logic';

export class CreateOrderItemDto {
  @IsString()
  @IsNotEmpty()
  @MaxLength(100)
  productId!: string;

  @IsInt()
  @Min(1)
  @Max(100)
  quantity!: number;
}

export class CreateOrderDto {
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CreateOrderItemDto)
  @ArrayMinSize(1)
  @ArrayMaxSize(20)
  items!: CreateOrderItemDto[];
}

export class AdminOrdersQueryDto {
  @IsOptional()
  @IsIn(ORDER_STATUSES)
  status?: OrderStatus;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(1)
  @Max(200)
  limit?: number;

  @IsOptional()
  @Type(() => Number)
  @IsInt()
  @Min(0)
  offset?: number;
}

export interface OrderItemDto {
  productId: string;
  productName: string;
  unitPrice: number;
  quantity: number;
  lineTotal: number;
}

export interface OrderDto {
  id: string;
  userId: string;
  status: string;
  statusLabel: string;
  totalAmount: number;
  currency: string;
  paymentId: string | null;
  failureReason: string | null;
  items: OrderItemDto[];
  createdAt: string;
  updatedAt: string;
  paidAt: string | null;
}

export interface AdminOrdersPage {
  items: OrderDto[];
  total: number;
  limit: number;
  offset: number;
}

export interface OrderItemRecordLike {
  productId: string;
  productName: string;
  unitPrice: number;
  quantity: number;
  lineTotal: number;
}

export interface OrderRecordLike {
  id: string;
  userId: string;
  status: string;
  totalAmount: number;
  currency: string;
  paymentId: string | null;
  failureReason: string | null;
  paidAt: Date | null;
  createdAt: Date;
  updatedAt: Date;
  items?: OrderItemRecordLike[];
}

export function toOrderDto(o: OrderRecordLike): OrderDto {
  return {
    id: o.id,
    userId: o.userId,
    status: o.status,
    statusLabel: toStatusLabel(o.status),
    totalAmount: o.totalAmount,
    currency: o.currency,
    paymentId: o.paymentId ?? null,
    failureReason: o.failureReason ?? null,
    items: (o.items ?? []).map((i) => ({
      productId: i.productId,
      productName: i.productName,
      unitPrice: i.unitPrice,
      quantity: i.quantity,
      lineTotal: i.lineTotal,
    })),
    createdAt: o.createdAt.toISOString(),
    updatedAt: o.updatedAt.toISOString(),
    paidAt: o.paidAt ? o.paidAt.toISOString() : null,
  };
}
