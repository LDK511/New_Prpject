import { Injectable, NotFoundException } from '@nestjs/common';
import { Prisma, Product } from '@prisma/client';
import { PrismaService } from '../prisma.service';
import { CreateProductDto, ProductDto, UpdateProductDto } from './dto';

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

function isUuid(v: string): boolean {
  return typeof v === 'string' && UUID_RE.test(v);
}

function toProductDto(p: Product): ProductDto {
  return {
    id: p.id,
    name: p.name,
    description: p.description,
    price: p.price,
    currency: p.currency,
    stock: p.stock,
    imageUrl: p.imageUrl ?? `https://placehold.co/300x200?text=${encodeURIComponent(p.name)}`,
    isActive: p.isActive,
    createdAt: p.createdAt.toISOString(),
    updatedAt: p.updatedAt.toISOString(),
  } as ProductDto;
}

@Injectable()
export class ProductsService {
  constructor(private readonly prisma: PrismaService) {}

  async list(): Promise<ProductDto[]> {
    const rows = await this.prisma.product.findMany({
      where: { isActive: true },
      orderBy: { createdAt: 'desc' },
    });
    return rows.map(toProductDto);
  }

  async get(id: string): Promise<ProductDto> {
    if (!isUuid(id)) throw new NotFoundException('Product not found');
    const p = await this.prisma.product.findUnique({ where: { id } });
    if (!p || !p.isActive) throw new NotFoundException('Product not found');
    return toProductDto(p);
  }

  async create(dto: CreateProductDto): Promise<ProductDto> {
    const p = await this.prisma.product.create({
      data: {
        name: dto.name,
        description: dto.description ?? '',
        price: dto.price,
        currency: 'KRW',
        stock: dto.stock,
        imageUrl: dto.imageUrl ?? null,
      },
    });
    return toProductDto(p);
  }

  async update(id: string, dto: UpdateProductDto): Promise<ProductDto> {
    if (!isUuid(id)) throw new NotFoundException('Product not found');

    const data: Prisma.ProductUpdateInput = {};
    if (dto.name !== undefined) data.name = dto.name;
    if (dto.description !== undefined) data.description = dto.description;
    if (dto.price !== undefined) data.price = dto.price;
    if (dto.stock !== undefined) data.stock = dto.stock;
    if (dto.imageUrl !== undefined) data.imageUrl = dto.imageUrl;
    if (dto.isActive !== undefined) data.isActive = dto.isActive;

    const updated = await this.prisma.$transaction(async (tx) => {
      // 재고 변경과 동시 예약이 섞이지 않도록 행을 먼저 잠급니다.
      const locked = await tx.$queryRaw<{ id: string }[]>`
        SELECT id FROM products WHERE id = ${id}::uuid FOR UPDATE`;
      if (locked.length === 0) throw new NotFoundException('Product not found');
      if (Object.keys(data).length === 0) {
        const current = await tx.product.findUnique({ where: { id } });
        if (!current) throw new NotFoundException('Product not found');
        return current;
      }
      return tx.product.update({ where: { id }, data });
    });
    return toProductDto(updated);
  }

  async remove(id: string): Promise<void> {
    if (!isUuid(id)) throw new NotFoundException('Product not found');
    const result = await this.prisma.product.updateMany({
      where: { id },
      data: { isActive: false },
    });
    if (result.count === 0) throw new NotFoundException('Product not found');
  }
}
