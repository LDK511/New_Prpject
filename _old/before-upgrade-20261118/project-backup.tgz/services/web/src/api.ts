// 게이트웨이(/api) 호출 — 같은 주소로 부르고 nginx 가 게이트웨이로 넘깁니다.

export interface User { id: string; email: string; role: 'USER' | 'ADMIN'; createdAt: string }
export interface Product {
  id: string; name: string; description: string; price: number; currency: string;
  stock: number; imageUrl: string; isActive: boolean; createdAt: string; updatedAt: string;
}
export interface OrderItem { productId: string; productName: string; unitPrice: number; quantity: number; lineTotal: number }
export interface Order {
  id: string; userId: string; status: string; statusLabel: string; totalAmount: number; currency: string;
  paymentId: string | null; failureReason: string | null; items: OrderItem[]; createdAt: string; updatedAt: string; paidAt: string | null;
}
export interface AdminOrdersPage { items: Order[]; total: number; limit: number; offset: number }

export class ApiError extends Error {
  constructor(public status: number, message: string) { super(message); }
}

const TOKEN_KEY = 'reshop.token';
export const tokenStore = {
  get(): string | null { try { return localStorage.getItem(TOKEN_KEY); } catch { return null; } },
  set(t: string | null) { try { t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY); } catch { /* 저장 불가 환경 */ } },
};

/** 서버 오류 메시지를 사람이 읽을 문장으로. */
function friendly(status: number, body: unknown): string {
  const raw = body && typeof body === 'object' ? (body as { message?: unknown }).message : undefined;
  const msg = Array.isArray(raw) ? raw.join(', ') : typeof raw === 'string' ? raw : '';
  if (status === 401) return '로그인이 필요하거나 이메일·비밀번호가 맞지 않아요.';
  if (status === 403) return '권한이 없어요.';
  if (status === 409) return msg.toLowerCase().includes('email') ? '이미 가입된 이메일이에요.' : '이미 처리된 요청이에요.';
  if (status === 429) return '시도가 너무 많아요. 잠시 후 다시 해 주세요.';
  if (status === 400) return msg ? `입력을 확인해 주세요 — ${msg}` : '입력을 확인해 주세요.';
  if (status >= 500) return '서버가 잠시 응답하지 않아요. 다시 시도해 주세요.';
  return msg || `요청 실패 (${status})`;
}

export async function api<T>(path: string, init: RequestInit & { json?: unknown } = {}): Promise<T> {
  const headers = new Headers(init.headers);
  const token = tokenStore.get();
  if (token) headers.set('Authorization', `Bearer ${token}`);
  let body = init.body;
  if (init.json !== undefined) { headers.set('Content-Type', 'application/json'); body = JSON.stringify(init.json); }
  let res: Response;
  try {
    res = await fetch(`/api${path}`, { ...init, headers, body });
  } catch {
    throw new ApiError(0, '서버에 연결하지 못했어요.');
  }
  const text = await res.text();
  let data: unknown = undefined;
  if (text) { try { data = JSON.parse(text); } catch { data = text; } }
  if (!res.ok) {
    if (res.status === 401 && token) tokenStore.set(null);
    throw new ApiError(res.status, friendly(res.status, data));
  }
  return data as T;
}

export const shop = {
  signup: (email: string, password: string) => api<User>('/auth/signup', { method: 'POST', json: { email, password } }),
  login: (email: string, password: string) =>
    api<{ accessToken: string; user: User }>('/auth/login', { method: 'POST', json: { email, password } }),
  me: () => api<User>('/users/me'),
  products: () => api<Product[]>('/products'),
  product: (id: string) => api<Product>(`/products/${encodeURIComponent(id)}`),
  createProduct: (p: { name: string; description?: string; price: number; stock: number; imageUrl?: string }) =>
    api<Product>('/products', { method: 'POST', json: p }),
  updateProduct: (id: string, p: Partial<Pick<Product, 'name' | 'description' | 'price' | 'stock' | 'isActive'>>) =>
    api<Product>(`/products/${encodeURIComponent(id)}`, { method: 'PATCH', json: p }),
  deleteProduct: (id: string) => api<void>(`/products/${encodeURIComponent(id)}`, { method: 'DELETE' }),
  order: (items: { productId: string; quantity: number }[], key: string) =>
    api<Order>('/orders', { method: 'POST', json: { items }, headers: { 'Idempotency-Key': key } }),
  orders: () => api<Order[]>('/orders'),
  cancel: (id: string) => api<Order>(`/orders/${encodeURIComponent(id)}/cancel`, { method: 'POST' }),
  adminOrders: () => api<AdminOrdersPage>('/admin/orders?limit=100'),
};

export const won = (n: number) => `${n.toLocaleString('ko-KR')}원`;

export function newKey(): string {
  const a = new Uint8Array(12);
  crypto.getRandomValues(a);
  return 'web-' + Array.from(a, (b) => b.toString(16).padStart(2, '0')).join('');
}
