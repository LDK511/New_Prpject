import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { ApiError, Order, Product, User, newKey, shop, tokenStore, won } from './api';

// ---------------------------------------------------------------------------
// 주소(#/...) — 새로 고침해도 같은 화면
// ---------------------------------------------------------------------------
type Route =
  | { page: 'home' } | { page: 'product'; id: string } | { page: 'cart' } | { page: 'login' } | { page: 'signup' }
  | { page: 'orders' } | { page: 'admin' };

function parse(hash: string): Route {
  const parts = hash.replace(/^#\/?/, '').split('/').filter(Boolean);
  switch (parts[0]) {
    case 'p': return parts[1] ? { page: 'product', id: decodeURIComponent(parts[1]) } : { page: 'home' };
    case 'cart': return { page: 'cart' };
    case 'login': return { page: 'login' };
    case 'signup': return { page: 'signup' };
    case 'orders': return { page: 'orders' };
    case 'admin': return { page: 'admin' };
    default: return { page: 'home' };
  }
}
const go = (path: string) => { window.location.hash = path; };

function useRoute(): Route {
  const [route, setRoute] = useState(() => parse(window.location.hash));
  useEffect(() => {
    const on = () => { setRoute(parse(window.location.hash)); window.scrollTo(0, 0); };
    window.addEventListener('hashchange', on);
    return () => window.removeEventListener('hashchange', on);
  }, []);
  return route;
}

// ---------------------------------------------------------------------------
// 장바구니 — 이 브라우저에 보관
// ---------------------------------------------------------------------------
type Cart = Record<string, number>;
const CART_KEY = 'reshop.cart';
function loadCart(): Cart {
  try { const v = JSON.parse(localStorage.getItem(CART_KEY) || '{}'); return v && typeof v === 'object' ? v : {}; } catch { return {}; }
}
function saveCart(c: Cart) { try { localStorage.setItem(CART_KEY, JSON.stringify(c)); } catch { /* 저장 불가 */ } }

// ---------------------------------------------------------------------------
// 공통 조각
// ---------------------------------------------------------------------------
const PALETTES = [['#fde68a', '#f59e0b'], ['#bfdbfe', '#3b82f6'], ['#c7d2fe', '#6366f1'], ['#bbf7d0', '#10b981'],
  ['#fecaca', '#ef4444'], ['#e9d5ff', '#a855f7'], ['#fed7aa', '#f97316'], ['#a5f3fc', '#06b6d4']];
function hash(s: string) { let h = 0; for (const c of s) h = (h * 31 + c.charCodeAt(0)) >>> 0; return h; }
function glyph(name: string): string {
  const n = name.toLowerCase();
  if (/keyboard|키보드/.test(n)) return '⌨️';
  if (/mouse|마우스/.test(n)) return '🖱️';
  if (/monitor|모니터|display/.test(n)) return '🖥️';
  if (/phone|폰/.test(n)) return '📱';
  if (/headphone|헤드폰|이어폰|earphone/.test(n)) return '🎧';
  if (/camera|카메라/.test(n)) return '📷';
  if (/watch|시계/.test(n)) return '⌚';
  if (/laptop|노트북/.test(n)) return '💻';
  if (/bag|가방/.test(n)) return '👜';
  if (/shoe|신발|운동화/.test(n)) return '👟';
  return '🛍️';
}

const ProductArt: React.FC<{ p: Product; big?: boolean }> = ({ p, big }) => {
  const [broken, setBroken] = useState(false);
  const real = p.imageUrl && !p.imageUrl.includes('placehold.co') && !broken;
  const [a, b] = PALETTES[hash(p.name) % PALETTES.length];
  return (
    <div className={`art${big ? ' big' : ''}`} style={real ? undefined : { background: `linear-gradient(135deg, ${a}, ${b})` }}>
      {real ? <img src={p.imageUrl} alt={p.name} onError={() => setBroken(true)} /> : <span aria-hidden>{glyph(p.name)}</span>}
    </div>
  );
};

const Notice: React.FC<{ kind?: 'error' | 'ok' | 'info'; children: React.ReactNode }> = ({ kind = 'info', children }) =>
  <div className={`notice ${kind}`} role={kind === 'error' ? 'alert' : 'status'}>{children}</div>;

const Loading: React.FC = () => <div className="loading"><span className="spin" />불러오는 중…</div>;

const statusTone = (s: string) => s === 'PAID_TEST' ? 'ok' : s === 'PENDING_PAYMENT' ? 'wait' : 'bad';

// ---------------------------------------------------------------------------
// 화면들
// ---------------------------------------------------------------------------
const Home: React.FC<{ onAdd: (p: Product) => void }> = ({ onAdd }) => {
  const [items, setItems] = useState<Product[] | null>(null);
  const [error, setError] = useState('');
  const [q, setQ] = useState('');
  useEffect(() => { shop.products().then(setItems).catch((e: ApiError) => setError(e.message)); }, []);
  const shown = useMemo(() => (items ?? []).filter((p) => !q || (p.name + p.description).toLowerCase().includes(q.toLowerCase())), [items, q]);
  return (
    <>
      <section className="hero">
        <div>
          <p className="eyebrow">ReShop · 테스트 결제 모드</p>
          <h1>필요한 장비를<br />한 곳에서.</h1>
          <p className="lead">회원 · 상품 · 주문 서비스가 각자 DB 를 쓰는 마이크로서비스 쇼핑몰입니다.</p>
        </div>
        <input className="search" placeholder="상품 검색" value={q} onChange={(e) => setQ(e.target.value)} aria-label="상품 검색" />
      </section>
      {error && <Notice kind="error">{error}</Notice>}
      {!items && !error && <Loading />}
      {items && !shown.length && <Notice>{q ? '검색 결과가 없어요.' : '아직 등록된 상품이 없어요.'}</Notice>}
      <div className="grid">
        {shown.map((p) => (
          <article key={p.id} className="card">
            <a href={`#/p/${encodeURIComponent(p.id)}`} className="card-link"><ProductArt p={p} /></a>
            <div className="card-body">
              <a href={`#/p/${encodeURIComponent(p.id)}`} className="card-title">{p.name}</a>
              <p className="muted clamp">{p.description || ' '}</p>
              <div className="card-foot">
                <b>{won(p.price)}</b>
                {p.stock > 0
                  ? <button className="btn sm" onClick={() => onAdd(p)}>담기</button>
                  : <span className="tag bad">품절</span>}
              </div>
            </div>
          </article>
        ))}
      </div>
    </>
  );
};

const Detail: React.FC<{ id: string; onAdd: (p: Product, n: number) => void }> = ({ id, onAdd }) => {
  const [p, setP] = useState<Product | null>(null);
  const [error, setError] = useState('');
  const [n, setN] = useState(1);
  useEffect(() => { setP(null); setError(''); shop.product(id).then(setP).catch((e: ApiError) => setError(e.status === 404 ? '없는 상품이에요.' : e.message)); }, [id]);
  if (error) return <><a href="#/" className="back">‹ 상품 목록</a><Notice kind="error">{error}</Notice></>;
  if (!p) return <Loading />;
  return (
    <>
      <a href="#/" className="back">‹ 상품 목록</a>
      <div className="detail">
        <ProductArt p={p} big />
        <div className="detail-info">
          <h1>{p.name}</h1>
          <p className="price">{won(p.price)}</p>
          <p className="muted">{p.description}</p>
          <p className={p.stock > 0 ? 'stock' : 'stock bad'}>{p.stock > 0 ? `재고 ${p.stock}개` : '품절'}</p>
          {p.stock > 0 && (
            <div className="row">
              <div className="qty">
                <button onClick={() => setN(Math.max(1, n - 1))} aria-label="하나 빼기">−</button>
                <span>{n}</span>
                <button onClick={() => setN(Math.min(p.stock, 100, n + 1))} aria-label="하나 더하기">+</button>
              </div>
              <button className="btn" onClick={() => onAdd(p, n)}>장바구니에 담기</button>
            </div>
          )}
        </div>
      </div>
    </>
  );
};

const CartPage: React.FC<{ cart: Cart; setCart: (c: Cart) => void; user: User | null }> = ({ cart, setCart, user }) => {
  const [products, setProducts] = useState<Product[] | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState<Order | null>(null);
  const [key, setKey] = useState(newKey);
  useEffect(() => { shop.products().then(setProducts).catch((e: ApiError) => setError(e.message)); }, []);
  const lines = (products ?? []).filter((p) => cart[p.id]).map((p) => ({ p, n: cart[p.id] }));
  const missing = Object.keys(cart).filter((id) => products && !products.some((p) => p.id === id));
  useEffect(() => {
    if (missing.length) { const c = { ...cart }; missing.forEach((id) => delete c[id]); setCart(c); }
  }, [missing.join(',')]); // eslint-disable-line react-hooks/exhaustive-deps
  const total = lines.reduce((s, l) => s + l.p.price * l.n, 0);
  const set = (id: string, n: number) => { const c = { ...cart }; if (n <= 0) delete c[id]; else c[id] = n; setCart(c); setKey(newKey()); };

  const checkout = async () => {
    if (!user) { go('/login'); return; }
    setBusy(true); setError('');
    try {
      const order = await shop.order(lines.map((l) => ({ productId: l.p.id, quantity: l.n })), key);
      setDone(order);
      if (order.status === 'PAID_TEST') setCart({});
      setKey(newKey());
    } catch (e) {
      setError((e as ApiError).message);
    } finally { setBusy(false); }
  };

  if (done) {
    const ok = done.status === 'PAID_TEST';
    return (
      <div className="panel center">
        <div className={`big-mark ${ok ? 'ok' : 'bad'}`}>{ok ? '✓' : '!'}</div>
        <h1>{ok ? '주문이 완료됐어요' : done.statusLabel}</h1>
        <p className="muted">주문번호 {done.id.slice(0, 8)} · {won(done.totalAmount)}{done.failureReason ? ` · ${done.failureReason}` : ''}</p>
        <div className="row center"><a className="btn" href="#/orders">주문 내역 보기</a><a className="btn ghost" href="#/">계속 쇼핑하기</a></div>
      </div>
    );
  }
  return (
    <>
      <h1 className="page-title">장바구니</h1>
      {error && <Notice kind="error">{error}</Notice>}
      {!products && !error && <Loading />}
      {products && !lines.length && <Notice>장바구니가 비어 있어요. <a href="#/">상품 보러 가기 ›</a></Notice>}
      {!!lines.length && (
        <div className="cart">
          <div className="panel">
            {lines.map(({ p, n }) => (
              <div key={p.id} className="line">
                <ProductArt p={p} />
                <div className="line-info"><b>{p.name}</b><span className="muted">{won(p.price)}</span></div>
                <div className="qty">
                  <button onClick={() => set(p.id, n - 1)} aria-label="하나 빼기">−</button>
                  <span>{n}</span>
                  <button onClick={() => set(p.id, Math.min(p.stock, 100, n + 1))} aria-label="하나 더하기">+</button>
                </div>
                <b className="line-total">{won(p.price * n)}</b>
                <button className="icon" onClick={() => set(p.id, 0)} aria-label={`${p.name} 빼기`}>✕</button>
              </div>
            ))}
          </div>
          <aside className="panel summary">
            <div className="sum-row"><span>상품 금액</span><b>{won(total)}</b></div>
            <div className="sum-row"><span>배송비</span><b>무료</b></div>
            <div className="sum-row total"><span>결제 금액</span><b>{won(total)}</b></div>
            <button className="btn wide" disabled={busy} onClick={checkout}>{busy ? '결제 중…' : user ? '주문하기' : '로그인하고 주문하기'}</button>
            <p className="muted small">테스트 결제 — 실제로 돈이 나가지 않아요.</p>
          </aside>
        </div>
      )}
    </>
  );
};

const AuthPage: React.FC<{ mode: 'login' | 'signup'; onLogin: (u: User) => void }> = ({ mode, onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true); setError('');
    try {
      if (mode === 'signup') await shop.signup(email, password);
      const r = await shop.login(email, password);
      tokenStore.set(r.accessToken);
      onLogin(r.user);
      go('/');
    } catch (err) { setError((err as ApiError).message); } finally { setBusy(false); }
  };
  return (
    <form className="panel auth" onSubmit={submit}>
      <h1>{mode === 'login' ? '로그인' : '회원가입'}</h1>
      <label>이메일<input type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} /></label>
      <label>비밀번호<input type="password" required minLength={mode === 'signup' ? 8 : 1} maxLength={72}
        autoComplete={mode === 'login' ? 'current-password' : 'new-password'} value={password} onChange={(e) => setPassword(e.target.value)} />
        {mode === 'signup' && <span className="muted small">8자 이상</span>}</label>
      {error && <Notice kind="error">{error}</Notice>}
      <button className="btn wide" disabled={busy}>{busy ? '처리 중…' : mode === 'login' ? '로그인' : '가입하고 시작하기'}</button>
      <p className="muted small center">
        {mode === 'login' ? <>처음이신가요? <a href="#/signup">회원가입</a></> : <>이미 계정이 있나요? <a href="#/login">로그인</a></>}
      </p>
    </form>
  );
};

const OrderCard: React.FC<{ o: Order; onCancel?: (o: Order) => void; showUser?: boolean }> = ({ o, onCancel, showUser }) => (
  <div className="panel order">
    <div className="order-head">
      <div><b>주문 {o.id.slice(0, 8)}</b><span className="muted small"> · {new Date(o.createdAt).toLocaleString('ko-KR')}{showUser ? ` · 회원 ${o.userId.slice(0, 8)}` : ''}</span></div>
      <span className={`tag ${statusTone(o.status)}`}>{o.statusLabel}</span>
    </div>
    <ul className="order-items">{o.items.map((i) => <li key={i.productId}><span>{i.productName} × {i.quantity}</span><span>{won(i.lineTotal)}</span></li>)}</ul>
    <div className="order-foot">
      <b>{won(o.totalAmount)}</b>
      {o.failureReason && <span className="muted small">{o.failureReason}</span>}
      {onCancel && o.status === 'PENDING_PAYMENT' && <button className="btn ghost sm" onClick={() => onCancel(o)}>주문 취소</button>}
    </div>
  </div>
);

const Orders: React.FC<{ user: User | null }> = ({ user }) => {
  const [orders, setOrders] = useState<Order[] | null>(null);
  const [error, setError] = useState('');
  const load = useCallback(() => { shop.orders().then(setOrders).catch((e: ApiError) => setError(e.message)); }, []);
  useEffect(() => { if (user) load(); }, [user, load]);
  if (!user) return <Notice>주문 내역은 로그인 후 볼 수 있어요. <a href="#/login">로그인 ›</a></Notice>;
  const cancel = async (o: Order) => {
    try { const u = await shop.cancel(o.id); setOrders((list) => (list ?? []).map((x) => (x.id === u.id ? u : x))); }
    catch (e) { setError((e as ApiError).message); }
  };
  return (
    <>
      <h1 className="page-title">주문 내역</h1>
      {error && <Notice kind="error">{error}</Notice>}
      {!orders && !error && <Loading />}
      {orders && !orders.length && <Notice>아직 주문이 없어요. <a href="#/">상품 보러 가기 ›</a></Notice>}
      <div className="stack">{(orders ?? []).map((o) => <OrderCard key={o.id} o={o} onCancel={cancel} />)}</div>
    </>
  );
};

const Admin: React.FC<{ user: User | null }> = ({ user }) => {
  const [tab, setTab] = useState<'products' | 'orders'>('products');
  const [products, setProducts] = useState<Product[] | null>(null);
  const [orders, setOrders] = useState<Order[] | null>(null);
  const [error, setError] = useState('');
  const [ok, setOk] = useState('');
  const [form, setForm] = useState({ name: '', description: '', price: '', stock: '' });
  const loadProducts = useCallback(() => { shop.products().then(setProducts).catch((e: ApiError) => setError(e.message)); }, []);
  useEffect(() => {
    if (user?.role !== 'ADMIN') return;
    if (tab === 'products') loadProducts();
    else shop.adminOrders().then((p) => setOrders(p.items)).catch((e: ApiError) => setError(e.message));
  }, [tab, user, loadProducts]);
  if (user?.role !== 'ADMIN') return <Notice kind="error">관리자만 볼 수 있어요.</Notice>;

  const run = async (fn: () => Promise<unknown>, msg: string) => {
    setError(''); setOk('');
    try { await fn(); setOk(msg); loadProducts(); } catch (e) { setError((e as ApiError).message); }
  };
  const create = (e: React.FormEvent) => {
    e.preventDefault();
    run(() => shop.createProduct({ name: form.name, description: form.description || undefined, price: Number(form.price), stock: Number(form.stock) }), '상품을 등록했어요.')
      .then(() => setForm({ name: '', description: '', price: '', stock: '' }));
  };
  return (
    <>
      <h1 className="page-title">관리자</h1>
      <div className="tabs">
        <button aria-pressed={tab === 'products'} onClick={() => setTab('products')}>상품 관리</button>
        <button aria-pressed={tab === 'orders'} onClick={() => setTab('orders')}>전체 주문</button>
      </div>
      {error && <Notice kind="error">{error}</Notice>}
      {ok && <Notice kind="ok">{ok}</Notice>}
      {tab === 'products' && (
        <>
          <form className="panel admin-form" onSubmit={create}>
            <input required placeholder="상품 이름" maxLength={200} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
            <input placeholder="설명" maxLength={2000} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
            <input required type="number" min={0} placeholder="가격(원)" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} />
            <input required type="number" min={0} placeholder="재고" value={form.stock} onChange={(e) => setForm({ ...form, stock: e.target.value })} />
            <button className="btn">등록</button>
          </form>
          {!products && <Loading />}
          <div className="panel">
            {(products ?? []).map((p) => (
              <div key={p.id} className="line">
                <ProductArt p={p} />
                <div className="line-info"><b>{p.name}</b><span className="muted">{won(p.price)} · 재고 {p.stock}</span></div>
                <button className="btn ghost sm" onClick={() => run(() => shop.updateProduct(p.id, { stock: p.stock + 10 }), `${p.name} 재고를 10개 늘렸어요.`)}>재고 +10</button>
                <button className="btn ghost sm danger" onClick={() => run(() => shop.deleteProduct(p.id), `${p.name} 을(를) 내렸어요.`)}>내리기</button>
              </div>
            ))}
          </div>
        </>
      )}
      {tab === 'orders' && (
        <div className="stack">
          {!orders && <Loading />}
          {orders && !orders.length && <Notice>주문이 없어요.</Notice>}
          {(orders ?? []).map((o) => <OrderCard key={o.id} o={o} showUser />)}
        </div>
      )}
    </>
  );
};

// ---------------------------------------------------------------------------
// 전체
// ---------------------------------------------------------------------------
export const App: React.FC = () => {
  const route = useRoute();
  const [user, setUser] = useState<User | null>(null);
  const [cart, setCartState] = useState<Cart>(loadCart);
  const [toast, setToast] = useState('');
  useEffect(() => { if (tokenStore.get()) shop.me().then(setUser).catch(() => tokenStore.set(null)); }, []);
  useEffect(() => { if (!toast) return; const t = setTimeout(() => setToast(''), 2200); return () => clearTimeout(t); }, [toast]);
  const setCart = (c: Cart) => { setCartState(c); saveCart(c); };
  const add = (p: Product, n = 1) => {
    setCart({ ...cart, [p.id]: Math.min(p.stock, 100, (cart[p.id] ?? 0) + n) });
    setToast(`${p.name} 을(를) 담았어요`);
  };
  const count = Object.values(cart).reduce((s, n) => s + n, 0);
  const logout = () => { tokenStore.set(null); setUser(null); go('/'); };

  return (
    <>
      <header className="top">
        <div className="wrap top-in">
          <a href="#/" className="logo"><span className="logo-mark">R</span>ReShop</a>
          <nav>
            <a href="#/" className={route.page === 'home' ? 'on' : ''}>상품</a>
            {user && <a href="#/orders" className={route.page === 'orders' ? 'on' : ''}>주문 내역</a>}
            {user?.role === 'ADMIN' && <a href="#/admin" className={route.page === 'admin' ? 'on' : ''}>관리자</a>}
            <a href="#/cart" className={`cart-link${route.page === 'cart' ? ' on' : ''}`}>장바구니{count > 0 && <span className="badge">{count}</span>}</a>
            {user
              ? <span className="who"><span className="muted small">{user.email}</span><button className="link" onClick={logout}>로그아웃</button></span>
              : <a href="#/login" className="btn sm">로그인</a>}
          </nav>
        </div>
      </header>
      <main className="wrap">
        {route.page === 'home' && <Home onAdd={(p) => add(p)} />}
        {route.page === 'product' && <Detail id={route.id} onAdd={add} />}
        {route.page === 'cart' && <CartPage cart={cart} setCart={setCart} user={user} />}
        {route.page === 'login' && <AuthPage mode="login" onLogin={setUser} />}
        {route.page === 'signup' && <AuthPage mode="signup" onLogin={setUser} />}
        {route.page === 'orders' && <Orders user={user} />}
        {route.page === 'admin' && <Admin user={user} />}
      </main>
      <footer className="wrap foot muted small">ReShop · 게이트웨이 · 회원 · 상품 · 주문 · 알림 워커 · 테스트 결제</footer>
      {toast && <div className="toast" role="status">{toast} · <a href="#/cart">장바구니 ›</a></div>}
    </>
  );
};
